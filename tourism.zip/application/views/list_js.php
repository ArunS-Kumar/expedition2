<script>
$(document).ready(function() {
    console.log('list js');
});
</script>