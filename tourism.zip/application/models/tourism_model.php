<?php
Class Tourism_model extends CI_Model
{

    var $CI;

    function __construct()
    {
		parent::__construct();

		$this->CI =& get_instance();
		$this->CI->load->database(); 
    }

	
	function get_all_tours($search)
	{
		$con = "AND";
		if(count($search) == 1) {
			$con = "OR";
			$search[1] = $search[0];
		}

		$tours = "SELECT t.*,s.name as style_name FROM tours t
					left join tour_styles ts on (ts.tour = t.id)
					inner join style s on (s.id = ts.style)
					left join tour_destinations td on (td.tour = t.id)
					left join destination d on (d.id = td.destination)
					inner join counties c on (c.id = d.country)
					where d.name like ? OR c.name like ? $con s.name like ? AND t.activate = 1
					GROUP BY t.id
					ORDER BY t.id ASC";

		$result['tours'] = $this->db->query($tours, array(trim($search[0]),trim($search[0]),trim($search[1])))->result();
		$result['destination'] = [];
		$result['types'] = [];
		$result['styles'] = [];
		
		if(!empty($result['tours'])) {
			foreach ($result['tours'] as $key => $value) {
				$tour_ids[] = $value->id;
			}

			$result['destination']  = $this->db->query("SELECT d.id,d.name FROM destination d
										left join tour_destinations td on (td.destination = d.id)
										where td.tour IN ('".implode("','",$tour_ids)."') GROUP BY d.name ORDER BY d.id")->result();
			
			$result['types']  = $this->db->query("SELECT t.id,t.name FROM type t
										left join tour_types tt on (tt.type = t.id)
										where tt.tour IN ('".implode("','",$tour_ids)."') GROUP BY t.name ORDER BY t.id")->result();

			$result['styles']  = $this->db->query("SELECT s.id,s.name FROM style s
										left join tour_styles ts on (ts.style = s.id)
										where ts.tour IN ('".implode("','",$tour_ids)."') GROUP BY s.name ORDER BY s.id")->result();
		}
		// echo "<pre>"; print_r($result); exit();
		return $result;
	}


	function get_tour($id) {
		$result = $this->db->get_where('tours', array('id'=>$id));
		return $result->row();
	}

	
}
