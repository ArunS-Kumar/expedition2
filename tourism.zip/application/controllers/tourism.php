<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class tourism extends CI_Controller {

	function __construct()
	{		
		parent::__construct();

		$this->load->model('tourism_model');
		$this->load->library('session');

	}

	public function index()
	{
		redirect('/');	
	}

	public function search() {

		if (count($_POST) > 0) {
			$this->session->set_userdata('postdata', $_POST ); 
			redirect('tourism/search');
		}
		else {
			if($this->session->userdata('postdata')) {
				$_POST = $this->session->userdata('postdata');
			}
		}
		
	
		$data['search'] = $search  = explode('+',$_POST['countries']);
		$tours  = $this->tourism_model->get_all_tours($search);

		$data['tours'] = $tours['tours'];
		$data['destination'] = $tours['destination'];
		$data['types'] = $tours['types'];
		$data['styles'] = $tours['styles'];

		$includes['js'] = ['list_js.php'];

		$this->load->view('header');
		$this->load->view('list', $data);
		$this->load->view('footer',$includes);
	}

	public function tour_detail() {

		if(!isset($_REQUEST['id']) || empty($_REQUEST['id'])) redirect('/');

		$data['search']  = explode('+',$this->session->userdata('postdata')['countries']);
		$id = $_REQUEST['id'];
		$data['tour']	  = $this->tourism_model->get_tour($id);

		$includes['js'] = ['details_js.php'];

		$this->load->view('header');
		$this->load->view('tour_details', $data);
		$this->load->view('footer',$includes);
	}	
}
